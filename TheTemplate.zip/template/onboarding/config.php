<?php
            $db_host = 'localhost';
            $db_name = 'yourDBName';
            $db_user = 'yourUserName';
            $db_pass = 'yourUserPass';

            
?>
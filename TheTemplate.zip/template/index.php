<?php
// Start the session and include required files
require_once 'session_start.php';

// Load branding data (will be used by header and footer)
if (!isset($brandingData) || empty($brandingData)) {
    try {
        require_once 'db_connection.php';
        $stmt = $conn->query("SELECT * FROM branding LIMIT 1");
        $dbBranding = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbBranding) {
            $brandingData = [
                'companyInfo' => [
                    'name' => $dbBranding['company_name'] ?? 'Hydroponics Shop Near Me',
                    'tagline' => $dbBranding['tagline'] ?? 'Find Local Hydroponic Supplies',
                    'websiteUrl' => $dbBranding['website_url'] ?? '/',
                    'foundedYear' => $dbBranding['founded_year'] ?? date('Y')
                ],
                'visualIdentity' => [
                    'logoUrl' => [
                        'primary' => $dbBranding['logo_url_primary'] ?? 'https://hydroponicshopnearme.com/logo.png',
                        'favicon' => $dbBranding['logo_url_favicon'] ?? 'favicon.ico'
                    ],
                    'colors' => [
                        'background' => $dbBranding['color_background'] ?? '#ffffff',
                        'primaryText' => $dbBranding['color_primary_text'] ?? '#333333',
                        'secondaryText' => $dbBranding['color_secondary_text'] ?? '#666666',
                        'button' => $dbBranding['color_button'] ?? '#0d904f',
                        'buttonText' => $dbBranding['color_button_text'] ?? '#ffffff'
                    ]
                ],
                'contentGuidelines' => [
                    'mainKeyword' => 'Hydroponics',
                    'categories' => []
                ],
                'socialMedia' => [
                    'facebook' => $dbBranding['social_facebook'] ?? '',
                    'twitter' => $dbBranding['social_twitter'] ?? '',
                    'instagram' => $dbBranding['social_instagram'] ?? '',
                    'linkedin' => $dbBranding['social_linkedin'] ?? '',
                    'youtube' => $dbBranding['social_youtube'] ?? ''
                ],
                'contactInformation' => [
                    'email' => $dbBranding['contact_email'] ?? 'info@hydroponicshopnearme.com',
                    'phone' => $dbBranding['contact_phone'] ?? '(555) 123-4567',
                    'address' => $dbBranding['contact_address'] ?? '123 Hydro Street, Garden City, NY 10001'
                ]
            ];
        }
    } catch(PDOException $e) {
        // Use default values if database query fails
        $brandingData = [
            'companyInfo' => [
                'name' => 'Hydroponics Shop Near Me',
                'tagline' => 'Find Local Hydroponic Supplies',
                'websiteUrl' => '/',
                'foundedYear' => date('Y')
            ],
            'visualIdentity' => [
                'logoUrl' => [
                    'primary' => 'https://hydroponicshopnearme.com/logo.png',
                    'favicon' => 'favicon.ico'
                ],
                'colors' => [
                    'background' => '#ffffff',
                    'primaryText' => '#333333',
                    'secondaryText' => '#666666',
                    'button' => '#0d904f',
                    'buttonText' => '#ffffff'
                ]
            ],
            'contentGuidelines' => [
                'mainKeyword' => 'Hydroponics',
                'categories' => []
            ],
            'socialMedia' => [],
            'contactInformation' => [
                'email' => 'info@hydroponicshopnearme.com',
                'phone' => '(555) 123-4567',
                'address' => '123 Hydro Street, Garden City, NY 10001'
            ]
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($brandingData['companyInfo']['name']) ? htmlspecialchars($brandingData['companyInfo']['name']) : 'Hydroponics Shop Near Me'; ?> | <?php echo isset($brandingData['companyInfo']['tagline']) ? htmlspecialchars($brandingData['companyInfo']['tagline']) : 'Find Local Hydroponic Supplies'; ?></title>
    
    <!-- Favicon -->
    <?php 
    $faviconUrl = isset($brandingData['visualIdentity']['logoUrl']['favicon']) ? 
                 htmlspecialchars($brandingData['visualIdentity']['logoUrl']['favicon']) : 
                 '/favicon.ico';
    $logoUrl = isset($brandingData['visualIdentity']['logoUrl']['primary']) ? 
              htmlspecialchars($brandingData['visualIdentity']['logoUrl']['primary']) : 
              'https://hydroponicshopnearme.com/logo.png';
    ?>
    <link rel="icon" type="image/png" href="<?php echo $faviconUrl; ?>">
    <link rel="apple-touch-icon" href="<?php echo $logoUrl; ?>">
    <link rel="shortcut icon" href="<?php echo $faviconUrl; ?>">
    
    <!-- Comprehensive favicon support -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $faviconUrl; ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $faviconUrl; ?>">
    <link rel="manifest" href="/site.webmanifest">
    <meta name="msapplication-TileColor" content="#0d904f">
    <meta name="theme-color" content="#0d904f">
    
    <!-- Primary Meta Tags -->
    <meta name="title" content="Hydroponics Shop Near Me | Find Local Hydroponic Supplies">
    <meta name="description" content="Find the best hydroponics shop near you. Quality hydroponic supplies, equipment, and expert advice for all your indoor gardening needs.">
    <meta name="keywords" content="hydroponics, hydroponic supplies, indoor gardening, grow shop, hydroponics store, hydroponic equipment, grow lights, nutrients">
    <meta name="author" content="Hydroponics Shop Near Me">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo isset($brandingData['companyInfo']['websiteUrl']) ? htmlspecialchars($brandingData['companyInfo']['websiteUrl']) : 'https://hydroponicshopnearme.com/'; ?>">
    <meta property="og:title" content="<?php echo isset($brandingData['companyInfo']['name']) ? htmlspecialchars($brandingData['companyInfo']['name']) : 'Hydroponics Shop Near Me'; ?> | <?php echo isset($brandingData['companyInfo']['tagline']) ? htmlspecialchars($brandingData['companyInfo']['tagline']) : 'Find Local Hydroponic Supplies'; ?>">
    <meta property="og:description" content="Find the best hydroponics shop near you. Quality hydroponic supplies, equipment, and expert advice for all your indoor gardening needs.">
    <meta property="og:image" content="<?php echo $logoUrl; ?>">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo isset($brandingData['companyInfo']['websiteUrl']) ? htmlspecialchars($brandingData['companyInfo']['websiteUrl']) : 'https://hydroponicshopnearme.com/'; ?>">
    <meta property="twitter:title" content="<?php echo isset($brandingData['companyInfo']['name']) ? htmlspecialchars($brandingData['companyInfo']['name']) : 'Hydroponics Shop Near Me'; ?> | <?php echo isset($brandingData['companyInfo']['tagline']) ? htmlspecialchars($brandingData['companyInfo']['tagline']) : 'Find Local Hydroponic Supplies'; ?>">
    <meta property="twitter:description" content="Find the best hydroponics shop near you. Quality hydroponic supplies, equipment, and expert advice for all your indoor gardening needs.">
    <meta property="twitter:image" content="<?php echo $logoUrl; ?>">
    
    <link rel="canonical" href="https://hydroponicshopnearme.com">
    <meta name="robots" content="index, follow">
    
    <!-- Additional SEO Meta Tags -->
    <meta name="geo.region" content="US">
    <meta name="geo.position" content="39.8283;-98.5795">
    <meta name="ICBM" content="39.8283, -98.5795">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Custom CSS variables that will override header/footer variables if needed */
        :root {
            --accent-color: #0d904f;
            --accent-color-light: #10b562;
            --accent-color-dark: #097a43;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            color: var(--primary-text-color, #333);
            background-color: var(--background-color, #ffffff);
        }
        
        a {
            text-decoration: none;
            color: #0d904f;
            transition: color 0.3s ease;
        }
        
        a:hover {
            color: #076835;
        }
        
        img {
            max-width: 100%;
            height: auto;
            display: block;
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header styles */
        header {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }
        
        .logo {
            display: flex;
            align-items: center;
        }
        
        .logo img {
            height: 50px;
            margin-right: 10px;
        }
        
        .logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0d904f;
        }
        
        .nav-toggle {
            display: none;
            position: absolute;
            top: 20px;
            right: 20px;
        }
        
        .close-menu {
            display: none;  /* Hide by default */
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #0d904f;
        }
        
        nav ul {
            display: flex;
            list-style: none;
        }
        
        nav li {
            margin-left: 30px;
        }
        
        nav a {
            font-weight: 600;
            font-size: 1.1rem;
            position: relative;
        }
        
        nav a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: #0d904f;
            transition: width 0.3s ease;
        }
        
        nav a:hover::after {
            width: 100%;
        }
        
        /* Hero section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://hydroponicshopnearme.com/hero-bg.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 120px 20px;
        }
        
        .hero-content {
            max-width: 800px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .hero h2 {
            font-size: 3rem;
            margin-bottom: 20px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
        }
        
        .hero p {
            font-size: 1.3rem;
            margin-bottom: 30px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        
        .search-container {
            display: flex;
            max-width: 600px;
            margin: 0 auto;
            background-color: white;
            border-radius: 50px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        
        .search-container input {
            flex: 1;
            padding: 15px 20px;
            border: none;
            font-size: 1.1rem;
            outline: none;
        }
        
        .search-container button {
            background-color: #0d904f;
            color: white;
            border: none;
            padding: 15px 25px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .search-container button:hover {
            background-color: #076835;
        }
        
        /* Features section */
        .features {
            padding: 80px 0;
            background-color: #fff;
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 50px;
        }
        
        .section-title h2 {
            font-size: 2.5rem;
            color: #333;
            position: relative;
            display: inline-block;
            margin-bottom: 15px;
        }
        
        .section-title h2::after {
            content: '';
            position: absolute;
            width: 60%;
            height: 3px;
            background-color: #0d904f;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }
        
        .section-title p {
            font-size: 1.2rem;
            color: #666;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .feature-card {
            background-color: #f5f5f5;
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
        
        .feature-img {
            height: 200px;
            overflow: hidden;
        }
        
        .feature-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .feature-card:hover .feature-img img {
            transform: scale(1.1);
        }
        
        .feature-content {
            padding: 25px;
        }
        
        .feature-content h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: #0d904f;
        }
        
        .feature-content p {
            margin-bottom: 20px;
            color: #666;
        }
        
        .btn {
            display: inline-block;
            background-color: #0d904f;
            color: white;
            padding: 10px 20px;
            border-radius: 50px;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        
        .btn:hover {
            background-color: #076835;
            color: white;
            transform: translateY(-3px);
        }
        
        /* Popular locations section */
        .locations {
            padding: 80px 0;
            background-color: #f0f8f3;
        }
        
        .locations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 40px;
        }
        
        .location-card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .location-card:hover {
            transform: translateY(-5px);
        }
        
        .location-img {
            height: 150px;
            overflow: hidden;
        }
        
        .location-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .location-card:hover .location-img img {
            transform: scale(1.1);
        }
        
        .location-content {
            padding: 20px;
            text-align: center;
        }
        
        .location-content h3 {
            margin-bottom: 10px;
            font-size: 1.3rem;
        }
        
        .location-content p {
            color: #666;
            margin-bottom: 15px;
        }
        
        /* About section */
        .about {
            padding: 80px 0;
            background-color: #fff;
        }
        
        .about-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
        }
        
        .about-content h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #333;
        }
        
        .about-content p {
            margin-bottom: 20px;
            color: #666;
            font-size: 1.1rem;
        }
        
        .about-image {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        /* Products section */
        .products {
            padding: 80px 0;
            background-color: #f0f8f3;
        }
        
        .products-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .product-card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
        }
        
        .product-img {
            height: 200px;
            overflow: hidden;
        }
        
        .product-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .product-card:hover .product-img img {
            transform: scale(1.1);
        }
        
        .product-content {
            padding: 20px;
        }
        
        .product-content h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: #0d904f;
        }
        
        .product-content p {
            color: #666;
            margin-bottom: 15px;
        }
        
        .product-price {
            font-weight: bold;
            color: #333;
            font-size: 1.2rem;
            margin-bottom: 15px;
        }
        
        /* Games section */
        .games {
            padding: 80px 0;
            background-color: #fff;
        }
        
        .games-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .game-card {
            background-color: #f5f5f5;
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .game-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
        
        .game-img {
            height: 180px;
            overflow: hidden;
            background-color: #e0f0e9;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .game-img img {
            max-width: 80%;
            max-height: 80%;
            object-fit: contain;
        }
        
        .game-content {
            padding: 25px;
        }
        
        .game-content h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: #0d904f;
        }
        
        .game-content p {
            margin-bottom: 20px;
            color: #666;
        }
        
        /* FAQ section */
        .faq {
            padding: 80px 0;
            background-color: #fff;
        }
        
        .faq-container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .accordion {
            margin-top: 40px;
        }
        
        .accordion-item {
            border-bottom: 1px solid #eee;
            margin-bottom: 15px;
        }
        
        .accordion-header {
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background-color 0.3s ease;
        }
        
        .accordion-header:hover {
            background-color: #e8e8e8;
        }
        
        .accordion-header h3 {
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        .accordion-icon {
            font-size: 1.2rem;
            transition: transform 0.3s ease;
        }
        
        .accordion-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            padding: 0 15px;
        }
        
        .accordion-content p {
            padding: 15px 0;
            color: #666;
        }
        
        .accordion-item.active .accordion-header {
            background-color: #e0f0e9;
        }
        
        .accordion-item.active .accordion-icon {
            transform: rotate(180deg);
        }
        
        .accordion-item.active .accordion-content {
            max-height: 300px;
        }
        
        /* CTA section */
        .cta {
            padding: 80px 0;
            background: linear-gradient(rgba(13, 144, 79, 0.9), rgba(7, 104, 53, 0.9)), url('https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2000&q=80') center/cover no-repeat;
            color: white;
            text-align: center;
        }
        
        .cta-container {
            max-width: 700px;
            margin: 0 auto;
        }
        
        .cta h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }
        
        .cta p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }
        
        .cta-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        
        .btn-white {
            background-color: white;
            color: #0d904f;
        }
        
        .btn-white:hover {
            background-color: #f0f0f0;
            color: #076835;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 2px solid white;
        }
        
        .btn-outline:hover {
            background-color: white;
            color: #0d904f;
        }
        
        /* Footer */
        footer {
            background-color: #222;
            color: #fff;
            padding: 60px 0 20px;
        }
        
        .footer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin-bottom: 30px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .footer-logo img {
            height: 40px;
            margin-right: 10px;
        }
        
        .footer-logo h2 {
            font-size: 1.5rem;
            color: white;
        }
        
        .footer-about p {
            color: #ccc;
            margin-bottom: 20px;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
        }
        
        .social-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: #333;
            border-radius: 50%;
            color: white;
            transition: background-color 0.3s ease;
        }
        
        .social-links a:hover {
            background-color: #0d904f;
        }
        
        .footer-links h3, .footer-contact h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            color: white;
            position: relative;
            padding-bottom: 10px;
        }
        
        .footer-links h3::after, .footer-contact h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background-color: #0d904f;
        }
        
        .footer-links ul {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 10px;
        }
        
        .footer-links a {
            color: #ccc;
            transition: color 0.3s ease, transform 0.3s ease;
            display: inline-block;
        }
        
        .footer-links a:hover {
            color: white;
            transform: translateX(5px);
        }
        
        .contact-info {
            margin-bottom: 20px;
        }
        
        .contact-info p {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
            color: #ccc;
        }
        
        .contact-info i {
            margin-right: 10px;
            color: #0d904f;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid #333;
            color: #999;
            font-size: 0.9rem;
        }
        
        /* Responsive styles */
        @media (max-width: 992px) {
            .header-container {
                flex-direction: column;
                padding: 15px 0 0;
            }
            
            nav {
                margin-top: 15px;
                width: 100%;
            }
            
            nav ul {
                justify-content: center;
                padding-bottom: 15px;
            }
            
            nav li {
                margin: 0 15px;
            }
            
            .hero h2 {
                font-size: 2.5rem;
            }
            
            .about-container {
                grid-template-columns: 1fr;
            }
            
            .about-image {
                order: -1;
            }
        }
        
        @media (max-width: 768px) {
            .nav-toggle {
                display: block;
                position: absolute;
                top: 20px;
                right: 20px;
            }
            
            nav {
                position: fixed;
                top: 0;
                left: -100%;
                width: 80%;
                height: 100vh;
                background-color: white;
                box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
                transition: left 0.3s ease;
                z-index: 1000;
                padding: 80px 20px 20px;
            }
            
            nav.active {
                left: 0;
            }
            
            nav.active .close-menu {
                display: block;  /* Only show close button when mobile menu is active */
            }
            
            nav ul {
                flex-direction: column;
                align-items: flex-start;
            }
            
            nav li {
                margin: 15px 0;
                width: 100%;
            }
            
            .hero h2 {
                font-size: 2rem;
            }
            
            .hero p {
                font-size: 1.1rem;
            }
            
            .search-container {
                flex-direction: column;
                border-radius: 10px;
            }
            
            .search-container input {
                width: 100%;
                border-radius: 10px 10px 0 0;
            }
            
            .search-container button {
                width: 100%;
                border-radius: 0 0 10px 10px;
            }
            
            .section-title h2 {
                font-size: 2rem;
            }
            
            .cta-buttons {
                flex-direction: column;
                gap: 15px;
            }
        }
        
        @media (max-width: 576px) {
            .hero {
                height: 70vh;
            }
            
            .hero h2 {
                font-size: 1.8rem;
            }
            
            .footer-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-content">
            <h2>Find the Best Hydroponics Shop Near You</h2>
            <p>Quality supplies, expert advice, and everything you need for successful indoor gardening</p>
            <div class="search-container">
                <input type="text" placeholder="Enter your city or zip code">
                <button>Find Shops</button>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="container">
            <div class="section-title">
                <h2>Why Choose Us</h2>
                <p>We connect you with the best local hydroponics suppliers to help your indoor garden thrive</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-img">
                        <img src="https://images.unsplash.com/photo-1558449028-b53a39d100fc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Local Shops">
                    </div>
                    <div class="feature-content">
                        <h3>Local Shops</h3>
                        <p>Find verified hydroponics shops in your area with detailed information, ratings, and reviews.</p>
                        <a href="#" class="btn">Find Shops</a>
                    </div>
                </div>
                <div class="feature-card">
                    <div class="feature-img">
                        <img src="https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Expert Advice">
                    </div>
                    <div class="feature-content">
                        <h3>Expert Advice</h3>
                        <p>Get guidance from experienced hydroponic gardeners and shop owners for your growing needs.</p>
                        <a href="#" class="btn">Learn More</a>
                    </div>
                </div>
                <div class="feature-card">
                    <div class="feature-img">
                        <img src="https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Quality Products">
                    </div>
                    <div class="feature-content">
                        <h3>Quality Products</h3>
                        <p>Access the best hydroponic equipment, nutrients, and supplies from reputable local vendors.</p>
                        <a href="#" class="btn">Browse Products</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Popular Locations Section -->
    <section class="locations" id="locations">
        <div class="container">
            <div class="section-title">
                <h2>Popular Locations</h2>
                <p>Find hydroponics shops in these major cities or search for your specific location</p>
            </div>
            <div class="locations-grid">
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1581373449483-37449f962b6c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="New York">
                    </div>
                    <div class="location-content">
                        <h3>New York</h3>
                        <p>12 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1515896769750-31548aa180ed?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Los Angeles">
                    </div>
                    <div class="location-content">
                        <h3>Los Angeles</h3>
                        <p>18 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Chicago">
                    </div>
                    <div class="location-content">
                        <h3>Chicago</h3>
                        <p>9 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1597714026720-8f74c62310ba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Miami">
                    </div>
                    <div class="location-content">
                        <h3>Miami</h3>
                        <p>7 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1546156929-a4c0ac411f47?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Denver">
                    </div>
                    <div class="location-content">
                        <h3>Denver</h3>
                        <p>11 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1612722432474-b971cdcea546?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Seattle">
                    </div>
                    <div class="location-content">
                        <h3>Seattle</h3>
                        <p>8 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1617469165786-8007eda3caa7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Austin">
                    </div>
                    <div class="location-content">
                        <h3>Austin</h3>
                        <p>6 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
                <div class="location-card">
                    <div class="location-img">
                        <img src="https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Portland">
                    </div>
                    <div class="location-content">
                        <h3>Portland</h3>
                        <p>5 Shops Available</p>
                        <a href="#" class="btn">View Shops</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="container about-container">
            <div class="about-content">
                <h2>About Hydroponics Shop Near Me</h2>
                <p>We're passionate about connecting indoor gardeners with the best local hydroponics shops. Our mission is to make it easy for you to find quality supplies and expert advice in your area.</p>
                <p>Whether you're a beginner just starting out or an experienced hydroponic grower, we help you locate the resources you need to succeed in your soil-less gardening journey.</p>
                <p>Our comprehensive directory includes verified shops, detailed information about products and services, and authentic reviews from fellow gardeners to help you make informed decisions.</p>
                <a href="#" class="btn">Learn More About Us</a>
            </div>
            <div class="about-image">
                <img src="https://hydroponicshopnearme.com/logo.png" alt="About Hydroponics Shop Near Me">
            </div>
        </div>
    </section>

    <!-- Products Section -->
    <section class="products">
        <div class="container">
            <div class="section-title">
                <h2>Our Products</h2>
                <p>Discover the best hydroponic supplies for your indoor garden</p>
            </div>
            <div class="products-container">
                <div class="product-card">
                    <div class="product-img">
                        <img src="https://images.unsplash.com/photo-1585155770447-2f66e2a397b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Hydroponic System">
                    </div>
                    <div class="product-content">
                        <h3>Complete Hydroponic System</h3>
                        <p>All-in-one system perfect for beginners and experienced growers alike.</p>
                        <p class="product-price">$149.99</p>
                        <a href="#" class="btn">View Details</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-img">
                        <img src="https://images.unsplash.com/photo-1558449028-b53a39d100fc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Nutrient Kit">
                    </div>
                    <div class="product-content">
                        <h3>Premium Nutrient Kit</h3>
                        <p>Balanced nutrients for optimal plant growth in any hydroponic system.</p>
                        <p class="product-price">$39.99</p>
                        <a href="#" class="btn">View Details</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-img">
                        <img src="https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Grow Lights">
                    </div>
                    <div class="product-content">
                        <h3>LED Grow Lights</h3>
                        <p>Energy-efficient full spectrum lights for indoor growing.</p>
                        <p class="product-price">$89.99</p>
                        <a href="#" class="btn">View Details</a>
                    </div>
                </div>
            </div>
            <div style="text-align: center; margin-top: 40px;">
                <a href="#" class="btn">View All Products</a>
            </div>
        </div>
    </section>

    <!-- Games Section -->
    <section class="games" id="games">
        <div class="container">
            <div class="section-title">
                <h2>Free Games to Play While Planting Plants!</h2>
                <p>Take a break and enjoy these fun hydroponic-themed games</p>
            </div>
            <div class="games-container">
                <div class="game-card">
                    <div class="game-img">
                        <img src="https://images.unsplash.com/photo-1585155770447-2f66e2a397b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Garden Defender">
                    </div>
                    <div class="game-content">
                        <h3>Garden Defender</h3>
                        <p>Protect your hydroponic garden from pests and diseases in this fun strategy game.</p>
                        <a href="#" class="btn">Play Now</a>
                    </div>
                </div>
                <div class="game-card">
                    <div class="game-img">
                        <img src="https://images.unsplash.com/photo-1558449028-b53a39d100fc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Idol Farm Clicker Game">
                    </div>
                    <div class="game-content">
                        <h3>Idol Farm Clicker Game</h3>
                        <p>Build and expand your virtual hydroponic farm in this addictive clicker game.</p>
                        <a href="#" class="btn">Play Now</a>
                    </div>
                </div>
                <div class="game-card">
                    <div class="game-img">
                        <img src="https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Hydroponics Word Search">
                    </div>
                    <div class="game-content">
                        <h3>Hydroponics Word Search</h3>
                        <p>Test your knowledge of hydroponics terminology with this challenging word search puzzle.</p>
                        <a href="#" class="btn">Play Now</a>
                    </div>
                </div>
            </div>
            <div style="text-align: center; margin-top: 40px;">
                <a href="#" class="btn">View All Games</a>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq" id="faq">
        <div class="container">
            <div class="section-title">
                <h2>Frequently Asked Questions</h2>
                <p>Get answers to common questions about hydroponics and finding the right supplies</p>
            </div>
            <div class="faq-container">
                <div class="accordion">
                    <div class="accordion-item">
                        <div class="accordion-header">
                            <h3>What is hydroponics?</h3>
                            <span class="accordion-icon">↓</span>
                        </div>
                        <div class="accordion-content">
                            <p>Hydroponics is a method of growing plants without soil, using mineral nutrient solutions in a water solvent. Plants can be grown with their roots exposed to the nutrient solution, or the roots may be supported by an inert medium such as perlite or gravel.</p>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <div class="accordion-header">
                            <h3>How do I find a hydroponics shop near me?</h3>
                            <span class="accordion-icon">↓</span>
                        </div>
                        <div class="accordion-content">
                            <p>Simply use our search function at the top of the page to enter your city, state, or zip code. We'll show you a list of verified hydroponics shops in your area, complete with reviews, product information, and contact details.</p>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <div class="accordion-header">
                            <h3>What should I look for in a hydroponics shop?</h3>
                            <span class="accordion-icon">↓</span>
                        </div>
                        <div class="accordion-content">
                            <p>A good hydroponics shop should offer quality equipment, nutrients, and growing media. Look for shops with knowledgeable staff who can provide advice, especially if you're a beginner. Our shop profiles highlight these aspects to help you make an informed choice.</p>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <div class="accordion-header">
                            <h3>I'm new to hydroponics. Where should I start?</h3>
                            <span class="accordion-icon">↓</span>
                        </div>
                        <div class="accordion-content">
                            <p>For beginners, we recommend starting with a simple system like a deep water culture (DWC) or wick system. Visit a local hydroponics shop from our directory and ask for beginner-friendly options. Many shops offer starter kits and can guide you through the setup process.</p>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <div class="accordion-header">
                            <h3>How can I list my hydroponics shop on your website?</h3>
                            <span class="accordion-icon">↓</span>
                        </div>
                        <div class="accordion-content">
                            <p>If you own a hydroponics shop and would like to be listed in our directory, please visit our "Add Your Shop" page or contact us directly. We'll need some basic information about your business, and we may verify your details before publishing your listing.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container cta-container">
            <h2>Ready to Find Your Perfect Hydroponics Shop?</h2>
            <p>Search for shops in your area and start growing with the best supplies and expert advice</p>
            <div class="cta-buttons">
                <a href="#" class="btn btn-white">Find Shops Now</a>
                <a href="#" class="btn btn-outline">Learn About Hydroponics</a>
            </div>
        </div>
    </section>

    <?php include 'footer.php'; ?>
    <script>
        // Mobile Navigation
        const navToggle = document.querySelector('.nav-toggle');
        const nav = document.querySelector('nav');
        const closeMenu = document.querySelector('.close-menu');
        
        navToggle.addEventListener('click', () => {
            nav.classList.add('active');
        });
        
        closeMenu.addEventListener('click', () => {
            nav.classList.remove('active');
        });
        
        // Testimonial Slider
        const slider = document.querySelector('.testimonial-slider');
        const prevBtn = document.querySelector('.prev-btn');
        const nextBtn = document.querySelector('.next-btn');
        const testimonials = document.querySelectorAll('.testimonial-card');
        
        let currentIndex = 0;
        const testimonialWidth = 100; // 100%
        
        function updateSlider() {
            if (slider) {
                slider.style.transform = `translateX(-${currentIndex * testimonialWidth}%)`;
            }
        }
        
        if (prevBtn && nextBtn) {
            prevBtn.addEventListener('click', () => {
                currentIndex = (currentIndex > 0) ? currentIndex - 1 : testimonials.length - 1;
                updateSlider();
            });
            
            nextBtn.addEventListener('click', () => {
                currentIndex = (currentIndex < testimonials.length - 1) ? currentIndex + 1 : 0;
                updateSlider();
            });
        }
        
        // FAQ Accordion
        const accordionItems = document.querySelectorAll('.accordion-item');
        
        accordionItems.forEach(item => {
            const header = item.querySelector('.accordion-header');
            
            header.addEventListener('click', () => {
                const currentlyActive = document.querySelector('.accordion-item.active');
                
                if(currentlyActive && currentlyActive !== item) {
                    currentlyActive.classList.remove('active');
                }
                
                item.classList.toggle('active');
            });
        });
        
        // Smooth scroll for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if(nav.classList.contains('active')) {
                    nav.classList.remove('active');
                }
            });
        });
        
        // Location search functionality
        const searchForm = document.querySelector('.search-container');
        const searchInput = document.querySelector('.search-container input');
        
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const location = searchInput.value.trim();
            
            if(location) {
                // In a real implementation, this would redirect to search results
                alert(`Searching for hydroponics shops near ${location}...`);
                // window.location.href = `/search?location=${encodeURIComponent(location)}`;
            }
        });
    </script>
</body>
</html>
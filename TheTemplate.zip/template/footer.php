<?php
// If brandingData isn't set (in case footer is included directly), load it from database
if (!isset($brandingData) || empty($brandingData)) {
    $brandingData = [];
    try {
        require_once 'db_connection.php';
        $stmt = $conn->query("SELECT * FROM branding LIMIT 1");
        $dbBranding = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbBranding) {
            $brandingData = [
                'companyInfo' => [
                    'name' => $dbBranding['company_name'] ?? 'Company Name',
                    'tagline' => $dbBranding['tagline'] ?? '',
                    'websiteUrl' => $dbBranding['website_url'] ?? '/',
                    'foundedYear' => $dbBranding['founded_year'] ?? date('Y')
                ],
                'visualIdentity' => [
                    'logoUrl' => [
                        'primary' => $dbBranding['logo_url_primary'] ?? 'default-logo.png',
                        'favicon' => $dbBranding['logo_url_favicon'] ?? 'favicon.ico'
                    ],
                    'colors' => [
                        'background' => $dbBranding['color_background'] ?? '#ffffff',
                        'primaryText' => $dbBranding['color_primary_text'] ?? '#333333',
                        'secondaryText' => $dbBranding['color_secondary_text'] ?? '#666666',
                        'button' => $dbBranding['color_button'] ?? '#e0e0e0',
                        'buttonText' => $dbBranding['color_button_text'] ?? '#333333'
                    ]
                ],
                'contentGuidelines' => [
                    'mainKeyword' => 'Product', // Default value
                    'categories' => [] // Will be populated if needed
                ],
                'socialMedia' => [
                    'facebook' => $dbBranding['social_facebook'] ?? '',
                    'twitter' => $dbBranding['social_twitter'] ?? '',
                    'instagram' => $dbBranding['social_instagram'] ?? '',
                    'linkedin' => $dbBranding['social_linkedin'] ?? '',
                    'youtube' => $dbBranding['social_youtube'] ?? ''
                ],
                'contactInformation' => [
                    'email' => $dbBranding['contact_email'] ?? '',
                    'phone' => $dbBranding['contact_phone'] ?? '',
                    'address' => $dbBranding['contact_address'] ?? ''
                ]
            ];
        }
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        // Use default values if database query fails
        $brandingData = [
            'companyInfo' => [
                'name' => 'Company Name',
                'tagline' => 'Your Tagline Here',
                'websiteUrl' => '/',
                'foundedYear' => date('Y')
            ],
            'visualIdentity' => [
                'logoUrl' => [
                    'primary' => 'default-logo.png',
                    'favicon' => 'favicon.ico'
                ],
                'colors' => [
                    'background' => '#ffffff',
                    'primaryText' => '#333333',
                    'secondaryText' => '#666666',
                    'button' => '#e0e0e0',
                    'buttonText' => '#333333'
                ]
            ],
            'contentGuidelines' => [
                'categories' => []
            ],
            'socialMedia' => [],
            'contactInformation' => [
                'phone' => '',
                'email' => '',
                'address' => ''
            ]
        ];
    }
}

// Load navigation data from navigation.json if not already loaded
if (!isset($navigation) || empty($navigation)) {
    $navigation = json_decode(file_get_contents('navigation.json'), true) ?? [
        'default' => ['sections' => []],
        'admin' => ['sections' => []],
        'header' => ['items' => []],
        'footer' => ['items' => []]
    ];
}

// Add error checking for the foreach loops
$categories = isset($brandingData['contentGuidelines']['categories']) ? $brandingData['contentGuidelines']['categories'] : [];
$socialMedia = isset($brandingData['socialMedia']) ? $brandingData['socialMedia'] : [];

// Check if we're on the login page (to adjust footer margins)
$isLoginPage = basename($_SERVER['PHP_SELF']) === 'login.php';

// Organize footer items into parent-child structure
$footerLinks = [];
$footerChildren = [];

if (isset($navigation['footer']['items']) && !empty($navigation['footer']['items'])) {
    // First, identify all items and their IDs
    $itemsById = [];
    foreach ($navigation['footer']['items'] as $item) {
        if (isset($item['id'])) {
            $itemsById[$item['id']] = $item;
        }
    }
    
    // Then organize into parent-child structure
    foreach ($navigation['footer']['items'] as $item) {
        if (isset($item['parent']) && !empty($item['parent']) && isset($itemsById[$item['parent']])) {
            if (!isset($footerChildren[$item['parent']])) {
                $footerChildren[$item['parent']] = [];
            }
            $footerChildren[$item['parent']][] = $item;
        } else {
            $footerLinks[] = $item;
        }
    }
    
    // Debug output
    error_log("Footer menu top-level items: " . count($footerLinks));
    error_log("Footer menu child items: " . print_r($footerChildren, true));
}

// Debug: Log the entire branding data structure
error_log("Footer branding data: " . print_r($brandingData, true));
?>
<footer class="main-footer <?php echo $isLoginPage ? 'login-page-footer' : ''; ?>">
    <div class="footer-container">
        <div class="footer-section company-info">
            <?php
            // Get the logo URL from branding data (matching dashboard approach)
            $logoUrl = isset($brandingData['visualIdentity']['logoUrl']['primary']) && 
                       !empty($brandingData['visualIdentity']['logoUrl']['primary']) 
                ? $brandingData['visualIdentity']['logoUrl']['primary']
                : '/images/logo.png';
                
            // Debug: Output the logo URL to see what's being passed
            error_log("Footer logo URL: " . $logoUrl);
            ?>
            <img src="<?php echo htmlspecialchars($logoUrl); ?>" 
                 alt="<?php echo htmlspecialchars($brandingData['companyInfo']['name']); ?>"
                 class="footer-logo"
                 onerror="this.onerror=null; this.src='/images/logo.png';">
            <p class="tagline"><?php echo htmlspecialchars($brandingData['companyInfo']['tagline']); ?></p>
            <div class="contact-info">
                <?php if (!empty($brandingData['contactInformation']['phone'])): ?>
                <p>
                    <i class="fas fa-phone"></i>
                    <a href="tel:<?php echo htmlspecialchars($brandingData['contactInformation']['phone']); ?>">
                        <?php echo formatPhone($brandingData['contactInformation']['phone']); ?>
                    </a>
                </p>
                <?php endif; ?>
                
                <?php if (!empty($brandingData['contactInformation']['email'])): ?>
                <p>
                    <i class="fas fa-envelope"></i>
                    <a href="mailto:<?php echo htmlspecialchars($brandingData['contactInformation']['email']); ?>">
                        <?php echo htmlspecialchars($brandingData['contactInformation']['email']); ?>
                    </a>
                </p>
                <?php endif; ?>
                
                <?php if (!empty($brandingData['contactInformation']['address'])): ?>
                <p>
                    <i class="fas fa-map-marker-alt"></i>
                    <?php echo htmlspecialchars($brandingData['contactInformation']['address']); ?>
                </p>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer-section links-section">
            <h3>Quick Links</h3>
            <ul>
                <?php if (!empty($footerLinks)): ?>
                    <?php foreach ($footerLinks as $link): ?>
                        <li>
                            <a href="<?php echo htmlspecialchars($link['url']); ?>">
                                <?php echo htmlspecialchars($link['title']); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Default footer links if none are specified -->
                    <li><a href="/about">About Us</a></li>
                    <li><a href="/contact">Contact</a></li>
                    <li><a href="/privacy-policy">Privacy Policy</a></li>
                    <li><a href="/terms">Terms of Service</a></li>
                    <li><a href="/sitemap">Sitemap</a></li>
                <?php endif; ?>
            </ul>
            
            <?php foreach ($footerLinks as $parentItem): ?>
                <?php if (isset($footerChildren[$parentItem['id']]) && !empty($footerChildren[$parentItem['id']])): ?>
                    <h3 class="footer-dropdown-title"><?php echo htmlspecialchars($parentItem['title']); ?></h3>
                    <div class="footer-dropdown-wrapper" data-dropdown-id="<?php echo strtolower(str_replace(' ', '-', $parentItem['title'])); ?>">
                        <ul>
                            <?php foreach ($footerChildren[$parentItem['id']] as $childItem): ?>
                                <li>
                                    <a href="<?php echo htmlspecialchars($childItem['url']); ?>">
                                        <?php echo htmlspecialchars($childItem['title']); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
            
            <?php if (!empty($categories)): ?>
            <h3 class="categories-title">Categories</h3>
            <div class="categories-wrapper">
                <ul class="categories-list">
                    <?php foreach ($categories as $category): ?>
                        <li><a href="/category/<?php echo strtolower(str_replace(' ', '-', $category)); ?>">
                            <?php echo htmlspecialchars($category); ?>
                        </a></li>
                    <?php endforeach; ?>
                </ul>
                <button class="view-more-btn">View More</button>
            </div>
            <?php endif; ?>
        </div>

        <div class="footer-section connect-section">
            <h3>Connect With Us</h3>
            <?php if (!empty($socialMedia)): ?>
            <div class="social-icons">
                <?php
                foreach ($socialMedia as $platform => $url):
                    if (!empty($url)):
                ?>
                    <a href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-<?php echo $platform; ?>"></i>
                    </a>
                <?php 
                    endif;
                endforeach;
                ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="footer-bottom">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($brandingData['companyInfo']['name']); ?>. 
               All rights reserved. Established <?php echo htmlspecialchars($brandingData['companyInfo']['foundedYear']); ?></p>
        </div>
    </div>
</footer>

<style>
.main-footer {
    background-color: var(--background-color);
    color: var(--primary-text-color);
    padding: 4rem 0 0;
    margin-top: 4rem;
    border-top: 1px solid rgba(0,0,0,0.1);
}

/* Remove margin when footer is on login page */
.login-page-footer {
    margin-top: 0;
}

.footer-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 2rem;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 2rem;
}

.footer-section h3 {
    color: var(--primary-text-color);
    margin-bottom: 1.5rem;
    font-size: 1.2rem;
    font-weight: 600;
}

.footer-section .categories-title {
    margin-top: 2rem;
}

.footer-logo {
    max-height: 40px;
    width: auto;
    margin-bottom: 1rem;
}

.company-info .tagline {
    color: var(--secondary-text-color);
    margin-bottom: 1.5rem;
}

.contact-info p {
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--secondary-text-color);
}

.contact-info a {
    color: var(--secondary-text-color);
    text-decoration: none;
    transition: color 0.2s ease;
}

.contact-info a:hover {
    color: var(--button-color);
}

.footer-section ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-section ul li {
    margin-bottom: 0.75rem;
}

.footer-section ul a {
    color: var(--secondary-text-color);
    text-decoration: none;
    transition: color 0.2s ease;
}

.footer-section ul a:hover {
    color: var(--button-color);
}

.social-icons {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
}

.social-icons a {
    color: var(--secondary-text-color);
    font-size: 1.5rem;
    transition: color 0.2s ease;
}

.social-icons a:hover {
    color: var(--button-color);
}

.footer-bottom {
    margin-top: 3rem;
    padding: 1.5rem 0;
    border-top: 1px solid rgba(0,0,0,0.1);
}

.footer-bottom .footer-container {
    text-align: center;
    display: block;
    padding: 0 1rem;
}

.footer-bottom p {
    color: var(--secondary-text-color);
    font-size: 0.9rem;
}

@media (max-width: 1024px) {
    .footer-container {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .connect-section {
        grid-column: span 2;
    }
}

@media (max-width: 768px) {
    .footer-container {
        grid-template-columns: 1fr;
    }
    
    .connect-section {
        grid-column: span 1;
    }
    
    .main-footer {
        padding: 2rem 0 0;
    }
    
    .footer-section {
        text-align: center;
    }
    
    .contact-info p {
        justify-content: center;
    }
    
    .social-icons {
        justify-content: center;
    }
}

.categories-wrapper {
    position: relative;
}

.categories-list {
    max-height: 150px;
    overflow: hidden;
    transition: max-height 0.3s ease-out;
}

.categories-list.expanded {
    max-height: 1000px; /* Large enough to show all content */
}

.view-more-btn {
    display: none; /* Hidden by default */
    width: 100%;
    padding: 0.5rem;
    background: var(--background-color);
    border: 1px solid var(--secondary-text-color);
    color: var(--secondary-text-color);
    cursor: pointer;
    margin-top: 0.5rem;
    transition: all 0.2s ease;
}

.view-more-btn:hover {
    background: var(--button-color);
    color: white;
    border-color: var(--button-color);
}

/* Show button only when content overflows */
.categories-wrapper.has-overflow .view-more-btn {
    display: block;
}

/* Footer dropdown styles */
.footer-dropdown-title {
    margin-top: 2rem;
    display: flex;
    align-items: center;
    cursor: pointer;
}

.footer-dropdown-title:after {
    content: "\f107";
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    margin-left: 0.5rem;
    transition: transform 0.3s ease;
}

.footer-dropdown-title.active:after {
    transform: rotate(180deg);
}

.footer-dropdown-wrapper {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease-out;
}

.footer-dropdown-wrapper.expanded {
    max-height: 500px; /* Large enough to show content */
}
</style>

<?php
// Helper function to format phone number
function formatPhone($phone) {
    $cleaned = preg_replace('/[^0-9]/', '', $phone);
    if(strlen($cleaned) == 10) {
        return sprintf("(%s) %s-%s",
            substr($cleaned, 0, 3),
            substr($cleaned, 3, 3),
            substr($cleaned, 6, 4)
        );
    }
    return $phone;
}
?>

<!-- Add Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle categories view more/less
    const categoriesWrapper = document.querySelector('.categories-wrapper');
    const categoriesList = document.querySelector('.categories-list');
    const viewMoreBtn = document.querySelector('.view-more-btn');
    
    // Check if elements exist before trying to use them
    if (categoriesWrapper && categoriesList && viewMoreBtn) {
        // Check if content overflows
        if (categoriesList.scrollHeight > 150) {
            categoriesWrapper.classList.add('has-overflow');
        }
        
        viewMoreBtn.addEventListener('click', function() {
            categoriesList.classList.toggle('expanded');
            this.textContent = categoriesList.classList.contains('expanded') ? 'View Less' : 'View More';
        });
    }
    
    // Handle footer dropdowns
    const footerDropdownTitles = document.querySelectorAll('.footer-dropdown-title');
    console.log('Found', footerDropdownTitles.length, 'footer dropdowns');
    
    footerDropdownTitles.forEach(title => {
        title.addEventListener('click', function() {
            console.log('Clicked footer dropdown:', this.textContent);
            this.classList.toggle('active');
            const wrapper = this.nextElementSibling;
            
            if (wrapper && wrapper.classList.contains('footer-dropdown-wrapper')) {
                wrapper.classList.toggle('expanded');
                console.log('Toggled dropdown state:', wrapper.classList.contains('expanded'));
                
                // If this dropdown is expanded, initialize its max-height to actual content height
                if (wrapper.classList.contains('expanded')) {
                    wrapper.style.maxHeight = wrapper.scrollHeight + 'px';
                } else {
                    wrapper.style.maxHeight = '0px';
                }
            }
        });
    });
    
    // Initialize footer dropdowns in collapsed state
    document.querySelectorAll('.footer-dropdown-wrapper').forEach(wrapper => {
        wrapper.style.maxHeight = '0px';
    });
});
</script>

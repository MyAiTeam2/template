<?php
// Start the session before ANY output
require_once 'session_start.php';

// Load navigation data from navigation.json
$navigation = json_decode(file_get_contents('navigation.json'), true) ?? [
    'default' => ['sections' => []],
    'admin' => ['sections' => []],
    'header' => ['items' => []],
    'footer' => ['items' => []]
];

// Load branding data from database only if not already loaded
if (!isset($brandingData) || empty($brandingData)) {
    $brandingData = [];
    try {
        require_once 'db_connection.php';
        $stmt = $conn->query("SELECT * FROM branding LIMIT 1");
        $dbBranding = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbBranding) {
            $brandingData = [
                'companyInfo' => [
                    'name' => $dbBranding['company_name'] ?? 'Company Name',
                    'tagline' => $dbBranding['tagline'] ?? '',
                    'websiteUrl' => $dbBranding['website_url'] ?? '/'
                ],
                'visualIdentity' => [
                    'logoUrl' => [
                        'primary' => $dbBranding['logo_url_primary'] ?? 'default-logo.png',
                        'favicon' => $dbBranding['logo_url_favicon'] ?? 'favicon.ico'
                    ],
                    'colors' => [
                        'background' => $dbBranding['color_background'] ?? '#ffffff',
                        'primaryText' => $dbBranding['color_primary_text'] ?? '#333333',
                        'secondaryText' => $dbBranding['color_secondary_text'] ?? '#666666',
                        'button' => $dbBranding['color_button'] ?? '#e0e0e0',
                        'buttonText' => $dbBranding['color_button_text'] ?? '#333333'
                    ]
                ],
                'contentGuidelines' => [
                    'mainKeyword' => 'Product', // Default value
                    'categories' => [] // Will be populated if needed
                ],
                'socialMedia' => [
                    'facebook' => $dbBranding['social_facebook'] ?? '',
                    'twitter' => $dbBranding['social_twitter'] ?? '',
                    'instagram' => $dbBranding['social_instagram'] ?? '',
                    'linkedin' => $dbBranding['social_linkedin'] ?? '',
                    'youtube' => $dbBranding['social_youtube'] ?? ''
                ],
                'contactInformation' => [
                    'email' => $dbBranding['contact_email'] ?? '',
                    'phone' => $dbBranding['contact_phone'] ?? '',
                    'address' => $dbBranding['contact_address'] ?? ''
                ]
            ];
        }
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        // Use default values if database query fails
        $brandingData = [
            'companyInfo' => [
                'name' => 'Company Name',
                'tagline' => 'Your Tagline Here',
                'websiteUrl' => '/'
            ],
            'visualIdentity' => [
                'logoUrl' => [
                    'primary' => 'default-logo.png',
                    'favicon' => 'favicon.ico'
                ],
                'colors' => [
                    'background' => '#ffffff',
                    'primaryText' => '#333333',
                    'secondaryText' => '#666666',
                    'button' => '#e0e0e0',
                    'buttonText' => '#333333'
                ]
            ],
            'contentGuidelines' => [
                'mainKeyword' => 'Product',
                'categories' => []
            ],
            'socialMedia' => [],
            'contactInformation' => []
        ];
    }
}

// Check if user is logged in and get user data
$isLoggedIn = isset($_SESSION['user_id']);

if ($isLoggedIn) {
    if (!isset($conn)) {
        require_once 'db_connection.php';
    }
    $stmt = $conn->prepare("SELECT full_name, is_admin FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    $userFullName = $userData ? $userData['full_name'] : 'User';
}

// Define CSS variables from branding data
$cssVariables = "
    :root {
        --background-color: " . htmlspecialchars($brandingData['visualIdentity']['colors']['background']) . ";
        --primary-text-color: " . htmlspecialchars($brandingData['visualIdentity']['colors']['primaryText']) . ";
        --secondary-text-color: " . htmlspecialchars($brandingData['visualIdentity']['colors']['secondaryText']) . ";
        --button-color: " . htmlspecialchars($brandingData['visualIdentity']['colors']['button']) . ";
        --button-text-color: " . htmlspecialchars($brandingData['visualIdentity']['colors']['buttonText']) . ";
    }
";
?>
<!-- Comprehensive Favicon Support -->
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo htmlspecialchars($brandingData['visualIdentity']['logoUrl']['favicon']); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo htmlspecialchars($brandingData['visualIdentity']['logoUrl']['favicon']); ?>">
<link rel="shortcut icon" href="<?php echo htmlspecialchars($brandingData['visualIdentity']['logoUrl']['favicon']); ?>">
<link rel="apple-touch-icon" href="<?php echo htmlspecialchars($brandingData['visualIdentity']['logoUrl']['favicon']); ?>">

<style><?php echo $cssVariables; ?></style>

<header class="main-header">
    <div class="header-container">
        <div class="logo">
            <?php
            // Get the logo URL from branding data (matching dashboard approach)
            $logoUrl = isset($brandingData['visualIdentity']['logoUrl']['primary']) && 
                       !empty($brandingData['visualIdentity']['logoUrl']['primary']) 
                ? $brandingData['visualIdentity']['logoUrl']['primary']
                : '/images/logo.png';
                
            // Debug: Output the logo URL
            error_log("Header logo URL: " . $logoUrl);
            ?>
            <a href="<?php echo htmlspecialchars($brandingData['companyInfo']['websiteUrl']); ?>" 
               title="<?php echo htmlspecialchars($brandingData['companyInfo']['name']); ?>">
                <img src="<?php echo htmlspecialchars($logoUrl); ?>" 
                     alt="<?php echo htmlspecialchars($brandingData['companyInfo']['name']); ?>"
                     title="<?php echo htmlspecialchars($brandingData['companyInfo']['tagline']); ?>"
                     onerror="this.onerror=null; this.src='/images/logo.png';">
            </a>
        </div>
        <div class="nav-items">
            <?php if (!$isLoggedIn): ?>
                <?php if (isset($navigation['header']['items']) && !empty($navigation['header']['items'])): ?>
                    <?php 
                    // Organize items into parent-child structure
                    $topLevelItems = [];
                    $childItems = [];
                    
                    // First, identify all items and their IDs
                    $itemsById = [];
                    foreach ($navigation['header']['items'] as $item) {
                        if (isset($item['id'])) {
                            $itemsById[$item['id']] = $item;
                        }
                    }
                    
                    // Then organize into parent-child structure
                    foreach ($navigation['header']['items'] as $item) {
                        if (isset($item['parent']) && !empty($item['parent']) && isset($itemsById[$item['parent']])) {
                            if (!isset($childItems[$item['parent']])) {
                                $childItems[$item['parent']] = [];
                            }
                            $childItems[$item['parent']][] = $item;
                        } else {
                            $topLevelItems[] = $item;
                        }
                    }
                    
                    // Debug output
                    error_log("Header menu top-level items: " . count($topLevelItems));
                    error_log("Header menu child items: " . print_r($childItems, true));
                    ?>
                    
                    <?php foreach ($topLevelItems as $item): ?>
                        <?php if (isset($childItems[$item['id']]) && !empty($childItems[$item['id']])): ?>
                            <div class="nav-dropdown">
                                <a href="#" class="dropdown-trigger">
                                    <?php echo htmlspecialchars($item['title']); ?> <i class="fas fa-chevron-down"></i>
                                </a>
                                <div class="dropdown-content">
                                    <?php foreach ($childItems[$item['id']] as $childItem): ?>
                                        <a href="<?php echo htmlspecialchars($childItem['url']); ?>">
                                            <?php echo htmlspecialchars($childItem['title']); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo htmlspecialchars($item['url']); ?>" id="<?php echo strtolower(str_replace(' ', '-', $item['title'])); ?>">
                                <?php echo htmlspecialchars($item['title']); ?>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Default navigation if no custom header navigation exists -->
                    <a href="<?php echo htmlspecialchars($brandingData['companyInfo']['websiteUrl']); ?>" id="search">
                        <?php echo htmlspecialchars($brandingData['contentGuidelines']['mainKeyword']); ?> Search
                    </a>
                    <a href="/blog" id="blog">Blog</a>
                    <a href="#" id="get-listed">Get Listed</a>
                <?php endif; ?>
                <a href="/login.php" id="sign-in" class="sign-in-button">Login</a>
            <?php else: ?>
                <?php if (isset($navigation['header']['items']) && !empty($navigation['header']['items'])): ?>
                    <?php 
                    // Organize items into parent-child structure
                    $topLevelItems = [];
                    $childItems = [];
                    
                    // First, identify all items and their IDs
                    $itemsById = [];
                    foreach ($navigation['header']['items'] as $item) {
                        if (isset($item['id'])) {
                            $itemsById[$item['id']] = $item;
                        }
                    }
                    
                    // Then organize into parent-child structure
                    foreach ($navigation['header']['items'] as $item) {
                        if (isset($item['parent']) && !empty($item['parent']) && isset($itemsById[$item['parent']])) {
                            if (!isset($childItems[$item['parent']])) {
                                $childItems[$item['parent']] = [];
                            }
                            $childItems[$item['parent']][] = $item;
                        } else {
                            $topLevelItems[] = $item;
                        }
                    }
                    
                    // Debug output
                    error_log("Header menu top-level items: " . count($topLevelItems));
                    error_log("Header menu child items: " . print_r($childItems, true));
                    ?>
                    
                    <?php foreach ($topLevelItems as $item): ?>
                        <?php if (isset($childItems[$item['id']]) && !empty($childItems[$item['id']])): ?>
                            <div class="nav-dropdown">
                                <a href="#" class="dropdown-trigger">
                                    <?php echo htmlspecialchars($item['title']); ?> <i class="fas fa-chevron-down"></i>
                                </a>
                                <div class="dropdown-content">
                                    <?php foreach ($childItems[$item['id']] as $childItem): ?>
                                        <a href="<?php echo htmlspecialchars($childItem['url']); ?>">
                                            <?php echo htmlspecialchars($childItem['title']); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo htmlspecialchars($item['url']); ?>" id="<?php echo strtolower(str_replace(' ', '-', $item['title'])); ?>">
                                <?php echo htmlspecialchars($item['title']); ?>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Default navigation if no custom header navigation exists -->
                    <a href="<?php echo htmlspecialchars($brandingData['companyInfo']['websiteUrl']); ?>" id="search">
                        <?php echo htmlspecialchars($brandingData['contentGuidelines']['mainKeyword']); ?> Search
                    </a>
                    <a href="/blog" id="blog">Blog</a>
                <?php endif; ?>
                <div class="user-menu-container">
                    <div class="user-welcome" id="userMenuTrigger">
                        <div class="user-welcome-content">
                            <span>Hello, <?php echo htmlspecialchars($userFullName); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="user-dropdown" id="userDropdown">
                        <a href="/dashboard.php" class="dropdown-item">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                        <hr class="dropdown-divider">
                        <a href="/logout.php" class="dropdown-item text-red-500">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</header>

<style>
.main-header {
    background-color: #ffffff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.header-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    font-size: 24px;
    font-weight: bold;
}

.logo img {
    max-height: 50px;
    width: auto;
}

.nav-items {
    display: flex;
    gap: 2rem;
    align-items: center;
}

.nav-items a {
    text-decoration: none;
    color: var(--primary-text-color);
    font-weight: 500;
    transition: color 0.2s ease;
}

.nav-items a:hover {
    color: var(--button-color);
}

#sign-in {
    padding: 0.5rem 1rem;
    border: 2px solid var(--button-color);
    border-radius: 4px;
    color: var(--button-color);
}

#sign-in:hover {
    background-color: var(--button-color);
    color: var(--button-text-color);
}

@media (max-width: 768px) {
    .header-container {
        padding: 1rem;
    }

    .nav-items {
        gap: 1rem;
    }
}

.user-menu-container {
    position: relative;
    cursor: pointer;
    padding-bottom: 20px;
    margin-bottom: -20px;
}

.user-welcome {
    padding: 0.5rem 1rem;
    border-radius: 4px;
    transition: all 0.2s ease;
    white-space: nowrap;
    color: var(--primary-text-color);
}

.user-welcome-content {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--primary-text-color);
}

.user-welcome-content span {
    color: var(--primary-text-color);
}

.user-welcome:hover {
    background-color: rgba(0, 0, 0, 0.05);
}

.user-welcome i {
    margin-left: 4px;
    transition: transform 0.3s ease;
}

.user-menu-container:hover .user-welcome i,
.user-menu-container.active .user-welcome i {
    transform: rotate(180deg);
}

.user-menu-container:hover .user-dropdown,
.user-dropdown:hover,
.user-dropdown.show {
    display: block;
    opacity: 1;
    visibility: visible;
}

.user-dropdown {
    padding-top: 8px;
    margin-top: -8px;
}

.user-dropdown {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    background-color: var(--background-color);
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    min-width: 200px;
    margin-top: 0.5rem;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.2s ease, visibility 0.2s ease;
}

.user-dropdown.show {
    display: block;
    animation: fadeIn 0.2s ease;
}

.dropdown-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    color: var(--primary-text-color);
    text-decoration: none;
    transition: background-color 0.2s ease;
}

.dropdown-item:hover {
    background-color: rgba(0, 0, 0, 0.05);
}

.dropdown-divider {
    margin: 0.5rem 0;
    border: none;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Update the navigation dropdown styles */
.nav-dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-trigger {
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.dropdown-trigger i {
    font-size: 0.8rem;
    transition: transform 0.3s ease;
}

/* Remove the hover styling that conflicts with JavaScript */
.dropdown-content {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    background-color: var(--background-color);
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    min-width: 200px;
    z-index: 1001;
    padding: 0.5rem 0;
}

.dropdown-content a {
    display: block;
    padding: 0.75rem 1rem;
    color: var(--primary-text-color);
    text-decoration: none;
    transition: background-color 0.2s ease;
}

.dropdown-content a:hover {
    background-color: rgba(0, 0, 0, 0.05);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle user menu dropdown
    const menuContainer = document.querySelector('.user-menu-container');
    const userDropdown = document.getElementById('userDropdown');
    let timeoutId;

    if (menuContainer && userDropdown) {
        // Handle click toggle
        menuContainer.addEventListener('click', (e) => {
            e.stopPropagation();
            menuContainer.classList.toggle('active');
            userDropdown.classList.toggle('show');
        });

        // Handle hover interactions
        menuContainer.addEventListener('mouseenter', () => {
            clearTimeout(timeoutId);
            userDropdown.classList.add('show');
            menuContainer.classList.add('active');
        });

        menuContainer.addEventListener('mouseleave', () => {
            timeoutId = setTimeout(() => {
                if (!userDropdown.classList.contains('show')) {
                    userDropdown.classList.remove('show');
                    menuContainer.classList.remove('active');
                }
            }, 300); // 300ms delay before hiding
        });

        // Keep menu open when moving to dropdown
        userDropdown.addEventListener('mouseenter', () => {
            clearTimeout(timeoutId);
        });

        userDropdown.addEventListener('mouseleave', () => {
            timeoutId = setTimeout(() => {
                if (!menuContainer.matches(':hover')) {
                    userDropdown.classList.remove('show');
                    menuContainer.classList.remove('active');
                }
            }, 300);
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!menuContainer.contains(e.target)) {
                userDropdown.classList.remove('show');
                menuContainer.classList.remove('active');
            }
        });
    }

    // Handle navigation dropdowns
    const navDropdowns = document.querySelectorAll('.nav-dropdown');
    console.log('Found', navDropdowns.length, 'navigation dropdowns');
    
    navDropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('.dropdown-trigger');
        const content = dropdown.querySelector('.dropdown-content');
        
        if (trigger && content) {
            console.log('Setting up dropdown for', trigger.textContent);
            
            // Force display block to make sure it's visible immediately on hover
            dropdown.addEventListener('mouseenter', () => {
                content.style.display = 'block';
                trigger.querySelector('i').style.transform = 'rotate(180deg)';
            });
            
            dropdown.addEventListener('mouseleave', () => {
                content.style.display = 'none';
                trigger.querySelector('i').style.transform = 'rotate(0deg)';
            });
            
            // Toggle dropdown on click (for mobile)
            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                if (content.style.display === 'block') {
                    content.style.display = 'none';
                    trigger.querySelector('i').style.transform = 'rotate(0deg)';
                } else {
                    // Close all other dropdowns
                    navDropdowns.forEach(other => {
                        if (other !== dropdown) {
                            const otherContent = other.querySelector('.dropdown-content');
                            const otherTrigger = other.querySelector('.dropdown-trigger');
                            if (otherContent && otherTrigger) {
                                otherContent.style.display = 'none';
                                otherTrigger.querySelector('i').style.transform = 'rotate(0deg)';
                            }
                        }
                    });
                    
                    content.style.display = 'block';
                    trigger.querySelector('i').style.transform = 'rotate(180deg)';
                }
            });
        }
    });
});
</script>
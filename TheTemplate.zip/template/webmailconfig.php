<?php
            $mailHost = 'yourmailserver';
            $mailSMTPAuth = true;
            $mailUsername = 'support@youremail.com';
            $mailPassword = 'yourmailpassword';
            $mailSMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mailPort = 587; // change to your mail server port
  
?>